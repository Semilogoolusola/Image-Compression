function Image_Saving(FileName_ImageO, ImageR, quality, Transform, Format)

    % Function that saves the reconstructed image and the JPEG version of
    % the tiff image.

    % INPUT:
        % FileName_ImageO = Filename of the original image
        % ImageR = Reconstructed image to be saved
        % quality = Quality of ImageR
        % Transform = Transform used for the compression
        % Format = Format of the file (bpm, tif, jpg)

    % Filename
    FileName_ImageO = convertStringsToChars(FileName_ImageO);
    Format = convertStringsToChars(Format);
    Index = strfind(FileName_ImageO, '.');
    FileName_ImageR = append(FileName_ImageO(1:Index(end)-1), "_Quality", num2str(quality), "_", Transform ,".", Format);
    
    % Saving image
    imwrite(ImageR, FileName_ImageR);   % Saving ImageR as an image.Format        
end