function [R_Image, C_Ratio, PSNR, MSE, Time,bits_after] = MainFunction(FileName, Transform, Quality,a)

tic
%% Parameters
    % % % Load the image and convert it
FileName = convertStringsToChars(FileName);
O_Image = imread(FileName);


Index = strfind(FileName, '.');
FileName_TXT = append(FileName(1:Index(end)-1), "_Quality",  num2str(a), "_", Transform , ".txt");
FileName_JPEG = append(FileName(1:Index(end)), "jpg");

%% Transform
O_Value = dct2(O_Image); % Perform DCT transformation

%% Quantization
Q=[];
C=size(O_Value)/2;
C=abs(O_Value(C(1),C(2)));  %Finds the center of O_value

%% Make a quantization matrix
for i=1:length(O_Image)
     for j=1:length(O_Image)
          Q(i,j)=((i-C)^2+(j-C)^2)/Quality;  
     end
end
 
% Quantized matrix
 O_Value=round(O_Value./Q);
%  Q=[ ];
% % Qt=[ ];
% ans=104; %the matrix on which we want to apply the quantization matrix (The DCT matrix)
% ans=cx;
% cx=cy;
% for i=1:512
%      for j=1:512
%           Q(i,j)=(i-cx)^2+(j-cy)^2;
%      end
% end

%% Packing of quantized bits
zizag_arr1 = zigzag(O_Value);
[code1, dict1] = huffman_encode(zizag_arr1);
 
%% Writing to a file header 
writematrix(code1, FileName_TXT);%% Save each bit stream into the txt file

 %% Unpacking of quantized bits
 vector1 = huffmandeco(code1, dict1);
 inv_zigzag1= inverse_zigzag( vector1);
 
 %% Dequantization and image reconstruction
 O_Value=inv_zigzag1.*Q;
 
 R_Image = round(abs(idct2(O_Value)));
 R_Image=uint8(R_Image);
 
% %  Save the image
%  imwrite(Image,"I_lenagray1.tif");

%% Compression ratio
    [r,c] = size(R_Image);
    bits_before = r * c * 8;
    bits_after = length(code1);
    
    C_Ratio = bits_before/bits_after;
 
    %% Comparison
    % JPEG image
    imwrite(O_Image, FileName_JPEG);     % Saving the image into a JPEG
    JPEG_Image = imread(FileName_JPEG);  % Read the image.jpg

    % Comparing O_Image and R_Image
    mse1 = immse(O_Image, R_Image);
    psnr1 = psnr(O_Image, R_Image);

    % Comparing O_Image and JPEG_Image
    mse2 = immse(O_Image, JPEG_Image);
    psnr2 = psnr(O_Image, JPEG_Image);

    % Comparing R_Image and JPEG_Image
    mse3 = immse(R_Image, JPEG_Image);
    psnr3 = psnr(R_Image, JPEG_Image);

    % Initializing the value for the containers
    KeySet = {'O-R','O-J','R-J'};
        % O-R : Comparing Original TIFF with Reconstructed TIFF
        % O-J : Comparing Original TIFF with JPEG
        % R-J : Comparing Reconstructed TIFF with JPEG
    ValuePSNR = [psnr1 psnr2 psnr3];
    ValueMSE = [mse1 mse2 mse3];
    % Containers
    PSNR = containers.Map(KeySet, ValuePSNR);
    MSE = containers.Map(KeySet, ValueMSE);
 %% Time
    Time = toc;
end
 
 