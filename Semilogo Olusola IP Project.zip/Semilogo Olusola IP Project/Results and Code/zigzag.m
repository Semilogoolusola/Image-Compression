function array = zigzag(matrix)
% zigzag computes the zigzag scan of a matrix. It turns the 2D matrix into
% 1D array.
%
%   Input:
%      matrix: 2D Image matrix of size N*N.
%
%   Output: 
%      array: the 1D zig-zag scan of the Image matrix of size N*N.
%
    
    [~, N] = size(matrix);
    p = N*N;
    
    %looping over the matrix to generate the 1D zig-zag array
    i = 1;
    for r = 1:N
        for c = 1:r
            if mod(r,2) ~= 0     %odd indices
                array(i) = matrix(r-c+1, c);
                array(p-i+1) = matrix(N-(r-c+1)+1, N-c+1);
                i = i+1;
            else                 %even indices
                array(i) = matrix(c, r-c+1);
                array(p-i+1) = matrix((N-c+1), N-(r-c+1)+1);
                i = i+1;
            end
            
        end
    end
    
end