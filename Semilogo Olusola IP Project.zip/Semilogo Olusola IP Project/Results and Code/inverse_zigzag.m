function matrix = inverse_zigzag(array)
% inverse_zigzag computes the inverse zigzag scan of an array. It turns a 1D array into a 2D matrix.
%
%   Input: 
%      array: the 1D zig-zag scan of the Image matrix of size N*N.
%
%   Output:
%      matrix: 2D Image matrix of size N*N.
%
       
    [~, p] = size(array);
    N = sqrt(p);

    %looping over the zig-zag array to generate the 2D matrix   
    i = 1;
    for r = 1:N
        for c = 1:r
            if mod(r,2) ~= 0       %odd indices
                matrix(r-c+1, c) = array(i);
                matrix(N-(r-c+1)+1, N-c+1) = array(p-i+1);
                i = i+1;
                
            else                   %even indices
                matrix(c, r-c+1) = array(i);
                matrix((N-c+1), N-(r-c+1)+1) = array(p-i+1);
                i = i+1;
            end
            
        end
    end
    
end