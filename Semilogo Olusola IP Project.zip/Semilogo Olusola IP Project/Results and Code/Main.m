clear; close all; clc;

%%  Inputs 
FileName = "I_lenagray.tif";
Transform = "DCT";
Quality = 1:0.1:10;

%%  Initialization
Flag = 1;
Q_Rate = zeros(1, size(Quality,2));
Q_PSNR_OR = zeros(1, size(Quality,2));
Q_PSNR_OJ = zeros(1, size(Quality,2));
Q_PSNR_RJ = zeros(1, size(Quality,2));
Q_MSE_OR = zeros(1, size(Quality,2));
Q_MSE_OJ = zeros(1, size(Quality,2));
Q_MSE_RJ = zeros(1, size(Quality,2));

%%  Loop
Pos_q = 0;
k=Quality;
Quality(Quality<=3)=Quality(Quality<=3)/10;
if(length(Quality)>=51)
    for i=1:length(Quality)
        Quality(i)=(Quality(i)^2)*10;
    end
end

for q = Quality
    Pos_q = Pos_q + 1;
    a=k(Pos_q);
    [R_Image, C_Rate, PSNR, MSE, ~,bits_after] = MainFunction(FileName, Transform, q,a);

    if Flag
        Dim = size(R_Image);
        Q_ImageR = uint8(zeros(Dim(1), Dim(2), size(Quality,2)));
        Flag = 0;
    end
    Q_ImageR(:,:,Pos_q) = R_Image;
    Q_Rate(1,Pos_q) = C_Rate;
    Q_PSNR_OR(1,Pos_q) = PSNR('O-R');
    Q_PSNR_OJ(1,Pos_q) = PSNR('O-J');    % Constant value
    Q_PSNR_RJ(1,Pos_q) = PSNR('R-J');
    Q_MSE_OR(1,Pos_q) = MSE('O-R');
    Q_MSE_OJ(1,Pos_q) = MSE('O-J');      % Constant value
    Q_MSE_RJ(1,Pos_q) = MSE('R-J');    
end

%% Figures
Quality =k ;
figure; plot(Quality, Q_PSNR_OR, 'r'); hold on; plot(Quality, Q_PSNR_OJ, 'b'); hold on; plot(Quality, Q_PSNR_RJ, 'g'); 
title('Peak Signal to Noise Ratio as a function of the quality'); legend('Original-Reconstructed', 'Original-JPEG', 'Reconstructed-JPEG');
xlabel("Quality"); ylabel("PSNR");

figure; plot(Quality, Q_MSE_OR, 'r'); hold on; plot(Quality, Q_MSE_OJ, 'b'); hold on; plot(Quality, Q_MSE_RJ, 'g'); 
title('Mean Square Error as a function of the quality'); legend('Original-Reconstructed', 'Original-JPEG', 'Reconstructed-JPEG');
xlabel("Quality"); ylabel("MSE");

figure; plot(Quality, Q_Rate); title('Compression rate as a function of the quality');
xlabel("Quality"); ylabel("Compression rate")

%% gif
TimePause = 0.2;
TimeGif = 5;
Gif(Quality, Q_ImageR, TimeGif, TimePause)