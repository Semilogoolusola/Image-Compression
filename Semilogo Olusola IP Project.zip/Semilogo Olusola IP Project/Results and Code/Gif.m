function Gif(Quality, Q_ImageR, TimeGif, TimePause)

    % INPUT:    
        % Quality = Vector of quality
        % Q_ImageR = Matrix containing the reconstructed image as a
        %            function of the quality.
        % TimeGif = Number of time the gif loops.
        % TimePause = Time for which one image appears.

    figure;
%     for i = 1:1:TimeGif
        Pos_j = 0;
        for j = Quality
            Pos_j = Pos_j+1;
            pause(TimePause)
            imshow(Q_ImageR(:,:,Pos_j))
        end
    end

% end